# X-Logcat-Lib
Logcat libary to get logcat of app
