package com.gameofcoding.xlogcat.utils;

public abstract class AppConstants {
    public static final String LOG_RECEIVER_PKG_NAME = "com.gameofcoding.xlogcat";
    public static final String ACTION_APP_LOG = "app_log_cat";
    public static final String KEY_APP_PACKAGE_NAME = "app_package_name";
    public static final String KEY_APP_LOG_LINE = "app_log_cat_line";
    public static final String KEY_ERROR = "error";
}
